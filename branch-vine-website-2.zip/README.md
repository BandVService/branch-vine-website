
# Branch and Vine Cleaning Service Website

## How to Run

1. Install dependencies:
   npm install

2. Add Tailwind CSS:
   Follow Tailwind installation: https://tailwindcss.com/docs/guides/create-react-app

3. Start the development server:
   npm start
